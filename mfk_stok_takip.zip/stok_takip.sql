-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 31 Ara 2019, 07:21:05
-- Sunucu sürümü: 10.4.10-MariaDB
-- PHP Sürümü: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `stok_takip`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `satislar`
--

CREATE TABLE `satislar` (
  `id` int(11) NOT NULL,
  `kategori` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `urunadi` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `beden` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `renk` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `fiyat` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `adet` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `aciklama` varchar(350) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `satislar`
--

INSERT INTO `satislar` (`id`, `kategori`, `urunadi`, `beden`, `renk`, `fiyat`, `adet`, `aciklama`) VALUES
(28, 'Erkek', 'Pantolon', '34', 'beyaz', '25', '3', 'kumas'),
(29, 'Erkek', 'Pantolon', '36', 'beyaz', '35', '1', 'kot'),
(30, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '2', 'kot'),
(31, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '2', 'kot'),
(32, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '2', 'kot'),
(33, 'Kadin', 'Pantolon', '32', 'siyah', '40', '2', 'kot'),
(34, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '1', 'kot'),
(35, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '1', 'kot'),
(36, 'Kadin', 'Pantolon', '32', 'siyah', '40', '3', 'kot'),
(37, 'Erkek', 'Kravat', '12', 'Siyah Desenli', '20', '1', 'Polyester'),
(38, 'Erkek', 'Pantolon', '36', 'beyaz', '35', '1', 'kot'),
(39, 'Kadin', 'Pantolon', '32', 'siyah', '40', '1', 'kot'),
(40, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '5', 'kot'),
(41, 'Erkek', 'Pantolon', '34', 'beyaz', '25', '7', 'kumas'),
(42, 'Erkek', 'Pantolon', '36', 'beyaz', '35', '1', 'kot'),
(43, 'Erkek', 'Pantolon', '36', 'beyaz', '45', '2', 'kot');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urunler`
--

CREATE TABLE `urunler` (
  `id` int(11) NOT NULL,
  `kategori` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `urunadi` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `beden` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `renk` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `fiyat` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `adet` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `aciklama` varchar(350) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `urunler`
--

INSERT INTO `urunler` (`id`, `kategori`, `urunadi`, `beden`, `renk`, `fiyat`, `adet`, `aciklama`) VALUES
(1, 'Erkek', 'Pantolon', '34', 'beyaz', '25', '0', 'kumas'),
(2, 'Erkek', 'Pantolon', '36', 'beyaz', '45', '15', 'kot'),
(3, 'Kadin', 'Pantolon', '32', 'siyah', '40', '16', 'kot'),
(4, 'Kadin', 'Gömlek', 'M', 'Beyaz', '25', '0', 'Yün'),
(7, 'çocuk', 'Pantolon', '30', 'beyaz', '20', '14', 'kot'),
(8, 'Erkek', 'Kravat', '12', 'Siyah Desenli', '20', '9', 'Polyester'),
(9, 'Kadin', 'Gömlek', 's', 'siyah', '25', '10', 'Yün'),
(10, 'Erkek', 'Fastway Ayakkab?', '42', 'Siyah', '200', '2', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `id` int(11) NOT NULL,
  `kategori` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kadi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `parola` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`id`, `kategori`, `kadi`, `parola`, `email`) VALUES
(1, 'Müdür', 'mfk', '123', 'ali@hotmail.com'),
(2, 'Satış Danışmanı', 'satici', '1', 'tolga@gmail.com'),
(3, 'Depocu', 'depocu', '1', 'dpocu@gmail.com');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `satislar`
--
ALTER TABLE `satislar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `urunler`
--
ALTER TABLE `urunler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `satislar`
--
ALTER TABLE `satislar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Tablo için AUTO_INCREMENT değeri `urunler`
--
ALTER TABLE `urunler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
