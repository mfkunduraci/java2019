/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stok_takip_programi;

/**
 *
 * @author MFK
 */
public interface urun {
    public String kategori="";
    public String urunadi="";
    public String beden="";
    public String renk="";
    public int adet=0;
    public int fiyat=0;
    public String aciklama="";
    
    
    
}
